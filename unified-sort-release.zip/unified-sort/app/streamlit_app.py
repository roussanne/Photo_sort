# Placeholder Streamlit app for Unified Sort
import streamlit as st
import unified_sort as us
st.set_page_config(page_title="Unified Sort", layout="wide", page_icon="📷")
st.title("Unified Sort – Placeholder App")
st.info("이 파일은 릴리스 템플릿입니다. 기존에 사용하던 app/streamlit_app.py로 교체해 실행하세요.")
